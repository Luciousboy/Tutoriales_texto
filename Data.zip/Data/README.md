### Data de prueba

Las notas pertencen al diario La Nación. Hay 100 notas de cada uno de los siguientes temas:

- aborto
- boca
- dólar
- trump

Las notas fueron seleccionados de forma tal que contengan esa palabra clave en el título. Las notas de "boca" pertenecen exclusivamente a la sección deportiva.



